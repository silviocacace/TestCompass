---
name: testcompass-flowchart
description: Guide for creating and validating TestCompass-compatible Mermaid flowcharts
---

# TestCompass Flowchart Skill

Use this skill when creating or validating Mermaid flowcharts for TestCompass import. It provides rules, validation criteria, and examples for building compliant flowchart models.

## When to Use

- Creating new flowcharts for TestCompass
- Validating existing Mermaid diagrams
- Converting flowcharts to TestCompass format
- Troubleshooting flowchart rendering errors
- Explaining TestCompass flowchart rules
- Resolving ambiguities or contradictions in source requirements before modeling them

## Ask Before You Build

Never guess your way past a problem in the source material. If anything prevents you from producing a flowchart that satisfies every rule below, stop and ask the user before writing or changing the diagram. A guessed resolution produces a chart that imports cleanly but models the wrong behavior.

### What to ask about

- **Ambiguities**: a step or decision that can be read more than one way; an unclear outcome; a condition whose "yes" and "no" meanings are not stated.
- **Contradictions**: two statements that cannot both hold (for example, one scenario says a report closes a trail and another says it never changes status).
- **Missing branches**: a decision with only one stated outcome, or a path that never reaches an End.
- **Multi-way choices**: more than two outcomes from one point. Ask how the user wants them split into a chain of Yes/No decisions, and in what order.
- **Convergence and loops**: paths that merge, or a "continue/return" step that loops back. Ask whether to merge, duplicate the shared node per path, or route to End.
- **Multiple actions after one step**: an action that must lead to more than one next step. Ask whether they are sequential, conditional, or alternatives.
- **Start and End**: no obvious single entry point, or no obvious terminal state.
- **Naming**: two different steps with the same label, or one step with several labels.
- **Scope**: whether to model every scenario or only a named subset, and whether roles (visitor, member, admin) are separate flows or one flow with decisions.
- **Anything else** that would force you to invent a rule, outcome, or label.

### How to ask

1. Read the entire source first and collect every problem before asking anything.
2. Batch related questions into one round. Do not ask one question at a time.
3. Quote or cite the source (file and line, or scenario ID) so the user sees exactly what is unclear.
4. Offer concrete options with a recommended default and its trade-off, and allow a free-text answer.
5. State any assumption you would otherwise make, so the user can correct it.
6. Do not write or modify the flowchart until blocking questions are answered. If only minor questions remain, proceed on a clearly stated assumption and list it in your final message.
7. After answers arrive, restate the resolved decisions briefly, then build the chart.
8. If a rule cannot be satisfied at all (for example, the source genuinely requires a loop), say so plainly and ask how the user wants to proceed rather than silently breaking the rule or the intent.

### Question template

> **Issue:** <one-line description>
> **Source:** <file:line or scenario ID>
> **Options:** (a) <option> (recommended: <why>), (b) <option>, (c) other
> **If unanswered, I will assume:** <default>

## Core Rules

### 1. Start Node
- Model must have **exactly one** Start node
- Start node must have **one single outgoing link**
- Start node must have **no incoming links**
- Format: `node_1@{shape: circle, label: "Start"}`

### 2. Action/State Nodes
- Must have **exactly one outgoing link**
- Can have multiple incoming links (convergence allowed)
- Represents a process, activity, or state
- Format: `node_X@{shape: document, label: "Action Name"}`

### 3. Decision Nodes
- Must have **exactly two outgoing links** (no more, no less)
- Can have multiple incoming links
- Right-side output is the **Yes path** (labeled `-- Yes -->`)
- Down-side output is the **No path** (labeled `-- No -->`)
- Format: `node_X@{shape: decision, label: "Question?"}`

### 4. Result/End Nodes
- Result nodes must have **exactly one outgoing link**
- End nodes have **no outgoing links**
- Can have multiple incoming links
- Model must have **at least one End node**
- Format: `node_X@{shape: double-circle, label: "End"}`

## Node Shapes

| Shape | Usage | Mermaid Code |
|-------|-------|------|
| circle | Start node only | `@{shape: circle, label: "Start"}` |
| decision | Binary decisions | `@{shape: decision, label: "Question?"}` |
| document | Actions, states, results | `@{shape: document, label: "Action"}` |
| double-circle | End node only | `@{shape: double-circle, label: "End"}` |

## Required Mermaid Format

```mermaid
---
title: "Flowchart Title"
---
flowchart TB
    node_1@{shape: circle, label: "Start"}
    node_2@{shape: document, label: "Action"}
    node_3@{shape: decision, label: "Decision?"}
    node_4@{shape: document, label: "Result"}
    node_5@{shape: double-circle, label: "End"}
    
    node_1 --> node_2
    node_2 --> node_3
    node_3 -- Yes --> node_4
    node_3 -- No --> node_5
    node_4 --> node_5
```

## Critical Validation Checklist

- [ ] Exactly one Start node
- [ ] Start node has exactly one outgoing link
- [ ] Start node has zero incoming links
- [ ] Every Action/State node has exactly one outgoing link
- [ ] Every Decision node has exactly two outgoing links
- [ ] Decision links labeled "Yes" or "No" only
- [ ] At least one End node
- [ ] End nodes have zero outgoing links
- [ ] No cycles (node cannot be ancestor of itself)
- [ ] No ambiguous labels (all node labels unique)
- [ ] All parent references exist as nodes
- [ ] No orphaned nodes (all connected to flow)

## Common Errors and Fixes

### ❌ "Failed to build hierarchy: ambiguous"
**Cause:** Duplicate node labels
**Fix:** Ensure every label is unique. Use qualified names like "Report Clear" instead of multiple "Report" nodes.

### ❌ "Failed to build hierarchy: cycle"
**Cause:** Circular parent-child relationship or node pointing to itself
**Fix:** Check that no node has itself as parent. Trace all paths to ensure they don't loop back.

### ❌ "Should have a single link coming out from action"
**Cause:** Action node has multiple outgoing edges
**Fix:** Action nodes must flow to exactly one next node. Use decision nodes for branching.

### ❌ "Should have at least one link coming in to result 'Start'"
**Cause:** Another node points to Start
**Fix:** Start should be root with no incoming edges. Remove edges pointing to Start.

### ❌ "Decision node has more than two outputs"
**Cause:** Decision node has 3+ outgoing edges
**Fix:** Decision nodes must have exactly 2 outputs: one labeled "Yes", one labeled "No".

## Handling Flowchart Complexity

### Problem: Convergence Points
When multiple paths need to merge at a single node (like multiple status checks converging to "View Reports"):

**Solution Options:**
1. **Separate Paths** (Recommended): Create independent paths that don't merge
2. **Sequential Routing**: Route through an intermediate decision node
3. **Replication**: Duplicate the convergence node under each parent path

### Problem: Parallel Actions
When users can take multiple actions:

**Solution:** Use sequential decision nodes that ask "Do X?" → "Yes/No" → "Do Y?" → etc.

## Node Numbering Convention

Use sequential node IDs (node_1, node_2, node_3, etc.) in order of definition. While not strictly required, it improves readability and debugging.

## Example: User Authentication Flow

```mermaid
---
title: "Authentication Flow"
---
flowchart TB
    node_1@{shape: circle, label: "Start"}
    node_2@{shape: decision, label: "Authenticated?"}
    node_3@{shape: document, label: "Login Form"}
    node_4@{shape: decision, label: "Credentials Valid?"}
    node_5@{shape: document, label: "Error Message"}
    node_6@{shape: document, label: "Dashboard"}
    node_7@{shape: double-circle, label: "End"}
    
    node_1 --> node_2
    node_2 -- No --> node_3
    node_3 --> node_4
    node_4 -- No --> node_5
    node_5 --> node_7
    node_4 -- Yes --> node_6
    node_2 -- Yes --> node_6
    node_6 --> node_7
```

## Best Practices

1. **Keep paths linear**: Minimize convergence by creating separate branches
2. **Use clear naming**: Labels should describe the action/decision clearly
3. **Validate early**: Check for ambiguous/cycle errors during development
4. **Test import**: Always test the final flowchart in TestCompass
5. **Document decisions**: Add comments explaining complex branching logic
6. **Node count**: Keep under 100 nodes for clarity; consider splitting into sub-flowcharts if larger

## Mermaid Syntax Reference

```
# Node definition
nodeID@{shape: shape_type, label: "Display Text"}

# Simple connection
nodeA --> nodeB

# Labeled connection
nodeA -- Label --> nodeB

# Decision paths
nodeA -- Yes --> nodeB
nodeA -- No --> nodeC

# Direction options (use TB for TestCompass)
flowchart TB    (top-to-bottom)
flowchart LR    (left-to-right)
flowchart BT    (bottom-to-top)
flowchart RL    (right-to-left)
```

## Troubleshooting Workflow

0. **Resolve open questions**: if a failure comes from the source logic rather than syntax, ask the user (see "Ask Before You Build") instead of patching around it
1. **Check syntax**: Verify all node definitions use `@{shape: ..., label: ...}` format
2. **Verify parents**: Ensure all referenced parents exist as node labels
3. **Count edges**: Manually verify each node's outgoing edge count
4. **Trace paths**: Follow each path from Start to End, checking for cycles
5. **Validate labels**: Check for duplicate or ambiguous labels
6. **Test render**: Import into TestCompass and check for warnings/errors

## References

- TestCompass Format Rules: See TESTCOMPASS_FLOWCHART_FORMAT.md
- Mermaid Documentation: https://mermaid.js.org/
- Node Shapes: circle, decision, document, double-circle
- Edge Labels: Must be "Yes" or "No" for decisions
